//jshint esversion:6
// >> Target
const nam_F=document.querySelector("#F_txt");
const nam_L=document.querySelector("#L_txt");
const nam_E=document.querySelector("#e_txt");
const sel=document.querySelector("#sel");
const mes=document.querySelector("#mes");
const but=document.querySelector("#but");
// >> Input

//>> submit
but.onclick=()=>{
};