//jshint esversion:6
// > nav_bar
const nav = document.querySelector("#navbar");
const home = nav.querySelector("li a[href='home.html']");
const gallery = nav.querySelector("li a[href='gallery.html']");
const form = nav.querySelector("li a[href='form.html']");
const about = nav.querySelector("li a[href='about.html']");
// >> nav_current
const tab_home = home.parentNode.classList;
//! ERROR ON PAGE ABOUT
//const tab_gallery = gallery.parentNode.classList;
const tab_form = form.parentNode.classList;
const tab_about = about.parentNode.classList;
// >> nav_style
// ! path_name not definite

//console.log(tab_style());
